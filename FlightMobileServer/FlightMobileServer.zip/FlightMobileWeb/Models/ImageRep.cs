﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightMobileWeb.Models
{
	/// <summary>
	/// A class that represents an image (sort of a wrapper) it holds an array of bytes.
	/// </summary>
	public class ImageRep
	{
		
	}
}
